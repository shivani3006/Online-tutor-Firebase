import React from 'react';
import sleeping from '../../../images/404.png';

const NotFound = () => {
    return (
        <div>
            <img className='w-100 ' src={sleeping} alt="" />
        </div>
    );
};

export default NotFound;